<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Details</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="bootstrap-5.3.3-dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2 class="my-4">Booking Details</h2>
        <?php
        // Impor file koneksi database
        require 'db_connect.php';

        // Ambil data booking terakhir
        $sql = "SELECT * FROM bookings ORDER BY id DESC LIMIT 1";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Tampilkan data booking
            while($row = $result->fetch_assoc()) {
                echo "<p>Nama Pemesan: " . $row["nama_pemesan"] . "</p>";
                echo "<p>Nomor Identitas: " . $row["nomor_identitas"] . "</p>";
                echo "<p>Jenis Kelamin: " . $row["jenis_kelamin"] . "</p>";
                echo "<p>Tipe Kamar: " . $row["tipe_kamar"] . "</p>";
                echo "<p>Durasi Menginap: " . $row["durasi_menginap"] . " Hari</p>";
                echo "<p>Discount: " . $row["discount"] . "%</p>";
                echo "<p>Total Bayar: Rp " . number_format($row["total_bayar"], 0, ',', '.') . "</p>";
            }
        } else {
            echo "Tidak ada data booking.";
        }

        $conn->close();
        ?>
    </div>
    <!-- Include Bootstrap JS scripts -->
    <script src="path/to/jquery.min.js"></script>
    <script src="path/to/popper.min.js"></script>
    <script src="bootstrap-5.3.3-dist/js/bootstrap.min.js"></script>
</body>
</html>